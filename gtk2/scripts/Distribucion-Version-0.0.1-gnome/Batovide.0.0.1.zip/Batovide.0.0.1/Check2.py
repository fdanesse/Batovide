#!/usr/bin/python

import sys
from pyflakes.scripts.pyflakes import main
sys.exit(main(sys.argv[1:]))